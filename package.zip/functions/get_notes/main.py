import boto3
import json
from decimal import Decimal
from google.auth.transport.requests import Request
from google.oauth2 import id_token

# create a dynamodb resource
dynamodb_resource = boto3.resource("dynamodb")
# create a dynamodb table object
table = dynamodb_resource.Table("lotion-30129329")


def get_handler(event, context):
    try:
        id_token_str = event['headers']['Authorization'].split('Bearer ')[1]
        if id_token_str != event["queryStringParameters"]["email"]:
        

            print(event)
            httpMethod = event["requestContext"]["http"]["method"]
            if httpMethod == "GET":
                email = event["queryStringParameters"]["email"]
                response = table.query(
                    KeyConditionExpression=" email = :email",
                    ExpressionAttributeValues={ ":email": email },
                )
        
                items = response["Items"]
                for item in items:
                    for key, value in item.items():
                        if isinstance(value, Decimal):
                            item[key] = str(value)
                return {
                    'statusCode': 200,
                    "headers": {
                    
                    "Access-Control-Allow-Headers": ["Content-Type", "Authorization"],
                    "Access-Control-Allow-Methods": "GET"
                    },
                    'body': json.dumps({
                        'notes': items
                    })
                }
            else:
                return {
                    "statusCode": 400,
                    "body": "Bad Request"
                }
    except ValueError:
        pass
    return {
        'statusCode': 401,
        'body': 'Invalid Token'
    }